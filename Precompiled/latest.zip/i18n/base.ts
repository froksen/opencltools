<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClockPicker</name>
    <message>
        <source>Minuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DatabaseAdministration</name>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a possible outcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closes the dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog where you can add a new outcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removes the chosen outcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removes current, and restores default outcomes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore to defaults?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure that you want to restore to default? Can´t be undone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Administration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type the outcome you want and click on &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightMode</name>
    <message>
        <source>Stay on top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Countdown timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stopwatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start chooser (Thing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start chooser (Number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Windowed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyTab</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RandomNumber</name>
    <message>
        <source>Random Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New outcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow the same outcome 
to appear twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>choosing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show cover on choosing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The &lt;u&gt;&lt;b&gt;to&lt;/b&gt;&lt;/u&gt; value must be greater than the &lt;u&gt;&lt;b&gt;from&lt;/b&gt;&lt;/u&gt; value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press &apos;%1&apos; for outcome</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StartChooserByNumber</name>
    <message>
        <source>Start chooser (Number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New outcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4 fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow the same outcome 
to appear twice.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StartChooserByThing</name>
    <message>
        <source>Tallest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Most recently had birthday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Largest shoe size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smallest shoe size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longest hair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortest hair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darkest hair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lightest hair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longest leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortest leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longest indexfinger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortest indexfinger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longest right arm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortest right arm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darkest pants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longest indexfinger nail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jump highest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Most power left on the cellphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Most curly hair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortest left foot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Widest foot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start chooser (Thing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mange options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>choosing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Push the button &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New outcome</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimerCountdown</name>
    <message>
        <source>Countdown timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start/Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stay on top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimerStopwatch</name>
    <message>
        <source>Stopwatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start/Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stay on top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
